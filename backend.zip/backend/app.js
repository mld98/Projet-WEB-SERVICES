const express = require('express');
const mongoose = require('mongoose');
const app = express();

bodyParser = require('body-parser');

const Neighbour = require('./models/Neighbour');


app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json())

mongoose.connect('mongodb+srv://lamine:MongoDbAtlas@123*@cluster0.dysk5.mongodb.net/Neighbourhood?retryWrites=true&w=majority',
  { useNewUrlParser: true,
    useUnifiedTopology: true })
  .then(() => console.log('Connexion à MongoDB réussie !'))
  .catch(() => console.log('Connexion à MongoDB échouée !'));

app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content, Accept, Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    next();
  });

//API pour créer un voisin
  app.post('/api/neighbour', (req, res, next) => {
      //delete req.body._id;
      const neighbour = new Neighbour({
        ...req.body
      });
      neighbour.save()
        .then(() => res.status(201).json({ message: 'Voisin enregistré !' }))
        .catch(error => res.status(400).json({ error }));
  });

//API pour modifier un voisin
app.put('/api/neighbour/:id', (req, res, next) => {
  Neighbour.updateOne({ _id: req.params.id }, {...req.body, _id: req.params.id})
    .then(() => res.status(200).json({ message: 'Voisin modifié !' }))
    .catch(error => res.status(400).json({ error }));
});

//API pour supprimer un voisin
app.delete('/api/neighbour/:id', (req, res, next) => {
  Neighbour.deleteOne({ _id: req.params.id })
    .then(() => res.status(200).json({ message: 'Voisin supprimé !' }))
    .catch(error => res.status(400).json({ error }));
});

//API pour consulter le détail d'un voisin
app.get('/api/neighbour/:id', (req, res, next) => {
  Neighbour.findOne({ _id: req.params.id })
    .then(neighbour => res.status(200).json(neighbour))
    .catch(error => res.status(404).json({ error }));
});

//API pour lister tous les voisins
app.get('/api/neighbour', (req, res, next) => {
    Neighbour.find()
      .then(neighbours => res.status(200).json(neighbours))
      .catch(error => res.status(400).json({ error }));
  });

module.exports = app;