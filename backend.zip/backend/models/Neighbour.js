const mongoose = require('mongoose');

const neighbourSchema = mongoose.Schema({
    name: {type: String, required: true},
    phone: {type: String, required: true},
    address: {type: String, required: true},
    about: {type: String, required: true},
    favorite: {type: Boolean, required: false},
});

module.exports = mongoose.model('Neighbour', neighbourSchema);